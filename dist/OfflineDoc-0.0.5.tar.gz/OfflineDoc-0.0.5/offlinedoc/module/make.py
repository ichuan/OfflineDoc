#!/usr/bin/env python
# coding: utf-8
# yc@2013/03/20

import os
import re
from offlinedoc.module._base import SingleHtmlModule


class Module(SingleHtmlModule):
    '''
    '''
    name = 'make'
    version = '0.71'
    url = 'http://www.gnu.org/software/make/manual/make.html'
