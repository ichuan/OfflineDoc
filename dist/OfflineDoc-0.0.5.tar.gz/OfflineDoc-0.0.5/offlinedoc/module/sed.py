#!/usr/bin/env python
# coding: utf-8
# yc@2013/03/20

import os
import re
from offlinedoc.module._base import SingleHtmlModule


class Module(SingleHtmlModule):
    '''
    '''
    name = 'sed'
    version = '4.2.1'
    url = 'http://www.gnu.org/software/sed/manual/sed.html'
