#!/usr/bin/env python
# coding: utf-8
# yc@2013/03/20

import os
import re
from offlinedoc.module._base import SingleHtmlModule


class Module(SingleHtmlModule):
    '''
    '''
    name = 'awk'
    version = '4.1'
    url = 'http://www.gnu.org/software/gawk/manual/gawk.html'
