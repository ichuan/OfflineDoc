===========
OfflineDoc
===========

OfflineDoc is a tool for generating html documents for public and private
projects.

Supported project types are:

1. Git
2. SVN
3. Single HTML page
4. Raw HTML pages


Supported project documention types are;

1. Raw HTML
2. Sphinx
3. jekyl
4. Others with makefile script

see http://guide.python-distribute.org/creation.html#readme-txt-description

Required:
1. nodejs: http://nodejs.org/dist/v0.10.24/node-v0.10.24-linux-x64.tar.gz
2. npm install -g grunt-cli && npm install bower -g
3. sudo apt-get install build-essential python-dev ruby1.9.1-dev git-core default-jre unzip rake
4. gem install jekyll
